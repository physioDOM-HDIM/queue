# Logger changelog

Version 1.1.0 ( 2014-09-18 - R12)
=================================
* Review dependancies
* Add a log viewer

# Version 1.0.0
===============
* first release
